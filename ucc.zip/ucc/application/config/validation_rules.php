<?php 

$config['user'] = array(
												array(
                          'field' => 'fullname',
                          'label' => 'Full Name',
                          'rules' => 'trim|callback_check_valid_name'
                        ),
                        array(
                          'field' => 'gender',
                          'label' => 'Gender',
                          'rules' => 'trim|required'
                        ),
                        array(
                          'field' => 'pro_langs[]',
                          'label' => 'Programming Language',
                          'rules' => 'trim|callback_check_programming_language'
                        ), 
                        array(
                          'field' => 'marital_status',
                          'label' => 'Marital Status',
                          'rules' => 'trim|required'
                        ), 
                        array(
                          'field' => 'address',
                          'label' => 'Address',
                          'rules' => 'trim|required'
                        ), 
                        array(
                          'field' => 'pic',
                          'label' => 'Picture',
                          'rules' => 'trim|callback_check_picture'
                        )
											); 