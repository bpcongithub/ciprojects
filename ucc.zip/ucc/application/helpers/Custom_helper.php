<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

if (!function_exists('show_checkboxes')) {
  function show_checkboxes($var = '') {
  	return $var;
  }   
}