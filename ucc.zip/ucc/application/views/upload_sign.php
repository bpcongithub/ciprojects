<?php $this->load->view('header'); ?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<?= $error; ?>
				<?= form_open_multipart('upload/upload_file'); ?> 
					<?= form_hidden('inv_id', 1);?>
					<input type="file" name="userfile" /> 
					<br>
					<input type="submit" value="Upload" />
				<?= form_close(); ?>
			</div>
		</div>
	</div>
<?php $this->load->view('footer'); ?>