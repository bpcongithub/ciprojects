<?php
$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
// $pdf->SetTitle('My Title');
// $pdf->SetHeaderMargin(30);
// $pdf->SetTopMargin(20);
// $pdf->setFooterMargin(20);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->SetAutoPageBreak(true);
// $pdf->SetAuthor('Author');
// $pdf->SetDisplayMode('real', 'default');

$pdf->AddPage();

// $pdf->Write(5, 'Some sample text');  

// $img_path = base_url().'assets/smpl.png'; 
$img_path = '../../assets/smpl.png';  

$html = ''; 

$html .= '
	<table border="">
		<tr> 
			<td> 
				<img src=" '.$img_path.' " border="0" height="32" width="32" /> 
			</td> 
		</tr>
    <tr style="text-align:left;">
    	<td> 
    		<img src=" '.$img_path.' " border="0" height="32" width="32" align="top" /> 
    	</td> 
    </tr>
		<tr style="text-align:center;"> 
			<td> 
				<img src=" '.$img_path.' " border="0" height="32" width="32" align="middle" /> 
			</td> 
		</tr>
		<tr style="text-align:right;"> 
			<td> 
				<img src=" '.$img_path.' " border="0" height="32" width="32" align="bottom" /> 
			</td> 
		</tr>
</table>
';

$pdf->writeHTML($html, true, false, true, false, '');

$pdf->Output(rand(100,999).'.pdf', 'D');
?>