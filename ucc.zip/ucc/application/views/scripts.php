		<script type="text/javascript" src="<?php echo base_url(); ?>assets/jquery-1.12.4/jquery.js"></script>
		<!-- <script type="text/javascript" src="<?php echo base_url(); ?>assets/jquery-ui-1.12.1/jquery-ui.js"></script>  --> 
		<script type="text/javascript" src="<?php echo base_url(); ?>assets/jquery-ui-1.12.1-new/jquery-ui.js"></script> 
		<script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap-3.3.7/js/bootstrap.min.js"></script>  
		<!-- <script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap-3.0.0/js/bootstrap.js"></script>  -->
		<script type="text/javascript" src="<?php echo base_url(); ?>assets/custom/custom_scripts.js"></script> 
		<script type="text/javascript" src="<?php echo base_url(); ?>assets/bootbox/bootbox.min.js"></script> 
		<script type="text/javascript">
		  var baseurl = "<?php echo base_url(); ?>";  
		  $(document).ready(function(){
				$('.dob').datepicker({
					dateFormat: 'dd-mm-yy',
					changeMonth: true,
      		changeYear: true,
      		maxDate: new Date(),
      		yearRange: "-100:+0",
				});
			});
		</script>