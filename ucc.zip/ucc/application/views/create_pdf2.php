<?php 
// echo "<pre>";print_r($inv_data);echo "</pre>";exit;
$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
// $pdf->SetTitle('My Title');
// $pdf->SetHeaderMargin(30);
// $pdf->SetTopMargin(20);
// $pdf->setFooterMargin(20);

$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// $pdf->SetAutoPageBreak(true, 0);
// $pdf->SetAuthor('Author');
// $pdf->SetDisplayMode('real', 'default');

$pdf->AddPage();

// $pdf->Write(5, 'Some sample text');  

// $img_path = base_url().'assets/smpl.png'; 
$img_path = '../../assets/smpl.png';  

$html = ''; 

/*
$html .= '
	<table border="" cellpadding="2">
		<tr> 
			<td width="16%" align="right">Client Code: </td>
			<td>'.$inv_data[0]['client_code'].'</td>
		</tr>
		<tr>
			<td width="16%">Member Code: </td>
			<td>'.$inv_data[0]['member_code'].'</td> 
		</tr>
	</table>
';
*/ 

$html .= '
	<b>&nbsp;&nbsp;&nbsp;&nbsp;Client code: </b>'.$inv_data[0]['client_code'].'
	<br>
	<b>Member code: </b>'.$inv_data[0]['member_code'].'
	<br><br>
'; 

$html .= '
	<table border="1" cellpadding="2">
		<tr> 
			<td colspan="2"><b>Investor 1 Detail</b></td>
		</tr>
		<tr>
			<td width="31%"><b>PAN Number </b></td>
			<td width="69%">'.$inv_data[0]['inv1_pan_no'].'</td> 
		</tr> 
		<tr>
			<td width="31%"><b>Name as per PAN </b></td>
			<td width="69%">'.$inv_data[0]['inv1_name'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Tax Status </b></td>
			<td width="69%">'.$inv_data[0]['inv1_tax_status'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Holding Nature </b></td>
			<td width="69%">'.$inv_data[0]['inv1_holding_nature'].'</td> 
		</tr> 
		<tr>
			<td width="31%"><b>Date of birth / Incorporation </b></td>
			<td width="69%">'.$inv_data[0]['inv1_dob'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Gender </b></td>
			<td width="69%">'.$inv_data[0]['inv1_gender'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Dividend payout mode </b></td>
			<td width="69%">'.$inv_data[0]['inv1_dividend_payout_mode'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Occupation </b></td>
			<td width="69%">'.$inv_data[0]['inv1_occupation'].'</td> 
		</tr> 
	</table>
	<br><br>
'; 

$html .= '
	<table border="1" cellpadding="2">
		<tr> 
			<td colspan="2"><b>Investor 2 Detail</b></td>
		</tr>
		<tr>
			<td width="31%"><b>PAN Number </b></td>
			<td width="69%">'.$inv_data[0]['inv2_pan_no'].'</td> 
		</tr> 
		<tr>
			<td width="31%"><b>Name as per PAN </b></td>
			<td width="69%">'.$inv_data[0]['inv2_name'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Tax Status </b></td>
			<td width="69%">'.$inv_data[0]['inv2_tax_status'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Holding Nature </b></td>
			<td width="69%">'.$inv_data[0]['inv2_holding_nature'].'</td> 
		</tr> 
		<tr>
			<td width="31%"><b>Date of birth / Incorporation </b></td>
			<td width="69%">'.$inv_data[0]['inv2_dob'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Gender </b></td>
			<td width="69%">'.$inv_data[0]['inv2_gender'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Dividend payout mode </b></td>
			<td width="69%">'.$inv_data[0]['inv2_dividend_payout_mode'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Occupation </b></td>
			<td width="69%">'.$inv_data[0]['inv2_occupation'].'</td> 
		</tr> 
	</table> 
	<br><br>
'; 

$html .= '
	<table border="1" cellpadding="2">
		<tr> 
			<td colspan="2"><b>Nominee Detail</b></td>
		</tr> 
		<tr>
			<td width="31%"><b>Name </b></td>
			<td width="69%">'.$inv_data[0]['nominee_name'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Relation </b></td>
			<td width="69%">'.$inv_data[0]['nominee_relation'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Address </b></td>
			<td width="69%">'.$inv_data[0]['nominee_address'].'</td> 
		</tr> 
		<tr>
			<td width="31%"><b>Pincode </b></td>
			<td width="69%">'.$inv_data[0]['nominee_pincode'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Country </b></td>
			<td width="69%">'.$inv_data[0]['nominee_country'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>State </b></td>
			<td width="69%">'.$inv_data[0]['nominee_state'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>City </b></td>
			<td width="69%">'.$inv_data[0]['nominee_city'].'</td> 
		</tr> 
	</table>
	<br><br>
'; 

$html .= '
	<table border="1" cellpadding="2" style="page-break-after: always;">
		<tr> 
			<td colspan="2"><b>Address Detail</b></td>
		</tr> 
		<tr>
			<td width="31%"><b>Address </b></td>
			<td width="69%">'.$inv_data[0]['address'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Pincode </b></td>
			<td width="69%">'.$inv_data[0]['pincode'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Country </b></td>
			<td width="69%">'.$inv_data[0]['country'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>State </b></td>
			<td width="69%">'.$inv_data[0]['state'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>City </b></td>
			<td width="69%">'.$inv_data[0]['city'].'</td> 
		</tr> 
	</table>
	<br><br>
'; 

$html .= '
	<table border="1" cellpadding="2">
		<tr> 
			<td colspan="2"><b>Account '.check_for_multiple_bank($inv_data[0]['default_bank']).' Detail</b></td>
		</tr> 
		<tr>
			<td width="31%"><b>Account Type </b></td>
			<td width="69%">'.$inv_data[0]['acc1_type'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Account Number </b></td>
			<td width="69%">'.$inv_data[0]['acc1_no'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>IFSC Code </b></td>
			<td width="69%">'.$inv_data[0]['acc1_ifsc'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>MICR Number </b></td>
			<td width="69%">'.$inv_data[0]['acc1_micr'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>Bank Name </b></td>
			<td width="69%">'.$inv_data[0]['acc1_bank_name'].'</td> 
		</tr> 
		<tr>
			<td width="31%"><b>Branch Name </b></td>
			<td width="69%">'.$inv_data[0]['acc1_branch_name'].'</td> 
		</tr> 
		<tr>
			<td width="31%"><b>Default Bank </b></td>
			<td width="69%">'.check_default_bank($inv_data[0]['default_bank'], "default1").'</td> 
		</tr> 
	</table> 
	<br><br>
';  

if($inv_data[0]['default_bank'] == "default2"){

	$html .= '
		<table border="1" cellpadding="2">
			<tr> 
				<td colspan="2"><b>Account 2 Detail</b></td>
			</tr> 
			<tr>
				<td width="31%"><b>Account Type </b></td>
				<td width="69%">'.$inv_data[0]['acc2_type'].'</td> 
			</tr>
			<tr>
				<td width="31%"><b>Account Number </b></td>
				<td width="69%">'.$inv_data[0]['acc2_no'].'</td> 
			</tr>
			<tr>
				<td width="31%"><b>IFSC Code </b></td>
				<td width="69%">'.$inv_data[0]['acc2_ifsc'].'</td> 
			</tr>
			<tr>
				<td width="31%"><b>MICR Number </b></td>
				<td width="69%">'.$inv_data[0]['acc2_micr'].'</td> 
			</tr>
			<tr>
				<td width="31%"><b>Bank Name </b></td>
				<td width="69%">'.$inv_data[0]['acc2_bank_name'].'</td> 
			</tr> 
			<tr>
				<td width="31%"><b>Branch Name </b></td>
				<td width="69%">'.$inv_data[0]['acc2_branch_name'].'</td> 
			</tr> 
			<tr>
				<td width="31%"><b>Default Bank </b></td>
				<td width="69%">'.check_default_bank($inv_data[0]['default_bank'], "default2").'</td> 
			</tr> 
		</table>
		<br><br>
	';

}

$html .= '
	<table border="1" cellpadding="2">
		<tr> 
			<td colspan="2"><b>Investor 1 CKYC Detail</b></td>
		</tr> 
		<tr>
			<td width="31%"><b>KYC Type </b></td>
			<td width="69%">'.$inv_data[0]['inv1_kyc_type'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>First holder CKYC number </b></td>
			<td width="69%">'.$inv_data[0]['inv1_ckyc_number'].'</td> 
		</tr> 
	</table> 
	<br><br>
';  

$html .= '
	<table border="1" cellpadding="2">
		<tr> 
			<td colspan="2"><b>Investor 2 CKYC Detail</b></td>
		</tr> 
		<tr>
			<td width="31%"><b>KYC Type </b></td>
			<td width="69%">'.$inv_data[0]['inv2_kyc_type'].'</td> 
		</tr>
		<tr>
			<td width="31%"><b>First holder CKYC number </b></td>
			<td width="69%">'.$inv_data[0]['inv1_ckyc_number'].'</td> 
		</tr> 
	</table> 
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
'; 

$html .= '
	<table style="cellpadding: 2px;">
		<tr>
			<td width="5%"></td>
			<td width="40%"><hr></td> 
			<td width="5%"></td>
			<td width="5%"></td> 
			<td width="40%"><hr></td>
			<td width="5%"></td>
		</tr>
		<tr> 
			<td width="5%"></td>
			<td width="40%" align="center">Signature</td> 
			<td width="5%"></td>
			<td width="5%"></td> 
			<td width="40%" align="center">Signature</td>
			<td width="5%"></td>
		</tr> 
	</table>
'; 

$pdf->writeHTML($html, true, false, true, false, '');

$pdf->Output(time().'.pdf', 'D'); 

function check_default_bank($stored_data, $cur_data){
	return ( $stored_data == $cur_data )?"yes":"no";
} 

function check_for_multiple_bank($stored_data){
	return ( $stored_data == "default2" )?"1":"";
}

?>