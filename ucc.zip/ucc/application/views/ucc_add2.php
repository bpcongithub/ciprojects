<?php $this->load->view('header'); ?> 
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/sweetalert/sweetalert.css">
    <br>
    <div class="container-fluid">
      <?php echo form_open_multipart('ucc2/store', array('id' => 'myform')); ?>
        <div class="panel panel-default">
          <div class="panel-heading"><b>Add</b></div>
          <div class="panel-body">
            <div class="form-group">
              <?php 
                echo form_label('Full Name');
                $fullname_attr = array(
                                  'name'  => 'fullname', 
                                  'id'    => 'fullname', 
                                  'class' => 'form-control'
                                );
                echo form_input($fullname_attr);  
              ?>
              <span class="span_err" id="fullname_err"></span>
            </div> 
            <div class="form-group">
              <?php
                echo form_label('Gender');
                $gender_options = array(
                            ''       => 'Please Select Gender',
                            'male'   => 'Male',
                            'female' => 'Female'
                          ); 
                $gender_attr = array(
                                'id'    => 'gender',
                                'class' => 'form-control'
                              ); 
                echo form_dropdown('gender', $gender_options, '', $gender_attr);
              ?> 
              <span class="span_err" id="gender_err"></span>
            </div>
            <div class="form-group">
              <?php 
                echo form_label('Known Programming Languages').br(); 
                $checkbox_options = array('HTML','CSS','JavaScript','jQuery','PHP');
                foreach($checkbox_options as $key => $val) {
              ?>
                  <label class="checkbox-inline">
                    <?php echo form_checkbox('pro_langs[]', strtolower($val), '').$val; ?>
                  </label>
              <?php
                }
              ?>
              <span class="span_err" id="pro_langs_err"></span>
            </div> 
            <div class="form-group">
              <?php 
                echo form_label('Marital Status').br(); 
                $radio_options = array('Single','Married','Divorced','Widowed');
                foreach($radio_options as $key2 => $val2) {
                  // $option_to_be_selected = strtolower($radio_options[0]); 
                  $option_to_be_selected = ''; 
                  $show_selected_option = ''; 
                  if( strtolower($val2) == $option_to_be_selected ){
                    $show_selected_option = true;
                  } 
              ?>
                  <label class="radio-inline">
                    <?php echo form_radio('marital_status', strtolower($val2), $show_selected_option).$val2; ?>
                  </label>
              <?php
                }
              ?>
              <span class="span_err" id="marital_status_err"></span>
            </div> 
            <div class="form-group">
              <?php 
                echo form_label('Residential Address');
                $address_attr = array(
                                  'name'  => 'address', 
                                  'id'    => 'address', 
                                  'class' => 'form-control',
                                  'rows'   => '1'
                                );
                echo form_textarea($address_attr);  
              ?>
              <span class="span_err" id="address_err"></span> 
            </div> 
            <div class="form-group">
              <?php 
                echo form_label('Picture');
                $pic_attr = array(
                                  'name'  => 'pic', 
                                  'id'    => 'pic', 
                                  'class' => 'form-control'
                                );
                echo form_upload($pic_attr);  
              ?>
              <span class="span_err" id="pic_err"></span>
            </div>
          </div> 
        </div>
        <button type="submit" class="btn btn-primary">Submit</button> 
      <?php echo form_close(); ?>
    </div>
    <br>
<?php $this->load->view('scripts'); ?>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/sweetalert/sweetalert.min.js"></script>
    <script type="text/javascript"> 

      $("#inv1_pan, #inv2_pan, #mobile").attr("maxlength","10"); 
      $("#nominee_pincode, #pincode").attr("maxlength","6");  
      $("#dv_2").hide();  
      $('#dv_2').find('input, textarea, button, select').prop('disabled',true);

      $("#inv1_pan, #inv2_pan").on("keyup", function(){
        this.value = this.value.toUpperCase();
      }); 

      $("#ifsc1, #ifsc2").on("keyup", function(){
        this.value = this.value.toUpperCase();
      }); 

      $("#nominee_pincode, #pincode, #acc1_no, #acc2_no, #residence_phone, #office_phone, #mobile").on("keypress", function (e) {
        var keyCode = e.which ? e.which : e.keyCode
        if (!(keyCode >= 48 && keyCode <= 57)) {
          return false;
        }
      });

      $(document).on('click', '.add_bank_btn', function(){
        swal({
          title: "Are you sure?",
          text: "Do you want to add more bank?",
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Yes",
          closeOnConfirm: true
        },
        function(){ 
          $('#dv_2').find('input, textarea, button, select').prop('disabled',false);
          $("#dv_2").show(); 
          $(".add_bank_btn").hide(); 
          $('.remove_bank_btn').css('visibility','visible');
        });
      }); 
      
      $(document).on('click', '.remove_bank_btn', function(){
        swal({
          title: "Are you sure?",
          text: "Do you want to remove?",
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Yes",
          closeOnConfirm: true
        },
        function(){
          try{   
            var sel = $('input[type=checkbox]:checked').map(function(_, el) {
              return $(el).attr('id');
            }).get();  
            if( sel == '' ){
              alert("Please select atleast one bank"); 
            }
            else{
              for(var i=0;i<sel.length;i++){
                var cur_str = sel[i];
                var last_char = cur_str.charAt(cur_str.length-1); 
                $('#dv_'+last_char).remove();
              } 
              var numItems = $('.bank-panel-body').length; 
              if( numItems == 1 ){
                $(".add_bank_btn").show();
                $('.remove_bank_btn').css('visibility','hidden');
              }
            } 
          }
          catch(e){
            alert(e.message);
          }
        });
      });     

      $(document).on("change", "input[name*='defaultbank']", function(){
        var last_radio_val = $('#radio-previous').val(); 
        if( last_radio_val == '' ){
        }
        else{
          last_radio_val = parseInt(last_radio_val);
          $('#removebank'+last_radio_val).prop('disabled',false);
        }
        var x = $(this).attr('id');
        var last_char = x.charAt(x.length-1);  
        last_char = parseInt(last_char); 
        if( last_char > 1 ){ 
          $('#removebank'+last_char).prop('checked',false);
          $('#removebank'+last_char).prop('disabled',true);
          $('#radio-previous').val(last_char);
        }
        else{
          $('#radio-previous').val();
        }
      });  

      // $("#gender option:first-child").prop("selectedIndex", 0).attr("disabled","disabled");

      $("#myform").on("submit", function(e){ 
        e.preventDefault();  
        var form_data = new FormData( document.getElementById("myform") ); 
        $.ajax({
          url: $(this).attr('action'),
          type: 'post',
          // dataType: "json",
          processData: false,
          contentType: false,
          // data: frm.serialize(), 
          data: form_data,
          success: function(res){    
            console.log(res);
            if( res.error == true ){
              $.each(res.fields, function (index, value) {
                // console.log("id: "+index+", value: "+value); 
                // id: fullname_error, value: <p>The Full Name field is required</p> 
                valid(index, value);              
              }); 
            }
            else{
              validate_clear();
              $("#myform")[0].reset();
              bootbox.alert(res.msg);
            }

            /*
            var response = JSON.parse(res);
            if (response['n'] == 0) {
              bootbox.alert(response['msg']);
            }
            else if (response['n'] == 1) {
              $(':input','#inv-form')
              .not('#nominee_country, #country, #defaultbank1')
              .val('')
              .prop('checked', false)
              .prop('selected', false);
              bootbox.alert({
                //title: "Success !!!",
                message: response['msg'],
                callback: function () {
                  location.href = baseurl+"ucc/get_data/"+response['data']; 
                  // location.reload();
                }
              });
            }
            else if (response['n'] == 2) {
              valid(response['field'], response['msg']);
            }
            else {
              bootbox.alert('An error was encountered');
            } 
            */ 
             
          },
          error: function(res){
            console.log(res);
          }
        });
      });   

    </script>
<?php $this->load->view('footer'); ?>