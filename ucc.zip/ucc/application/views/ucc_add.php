<?php $this->load->view('header'); ?> 
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/sweetalert/sweetalert.css">
    <br>
    <div class="container-fluid">
      <form id="inv-form" method="post" action="<?= base_url(); ?>ucc2/store">
        <div class="panel panel-default">
          <div class="panel-heading"><b>Investor 1</b></div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>PAN Number</label>
                  <input type="text" class="form-control" placeholder="PAN Number" id="inv1_pan" name="inv1_pan">
                  <span class="span_err" id="inv1_pan_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Name as per PAN</label>
                  <input type="text" class="form-control" placeholder="Name as per PAN" id="inv1_name" name="inv1_name"> 
                  <span class="span_err" id="inv1_name_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Tax Status</label> 
                  <select class="form-control" id="inv1_tax" name="inv1_tax">
                    <option value="">Select Tax Status</option> 
                    <option value="individual">Individual</option> 
                    <option value="huf">HUF</option> 
                    <option value="partnership">Partnership</option> 
                    <option value="llp">LLP</option> 
                    <option value="company">Company</option> 
                    <option value="trust">Trust</option>
                  </select>
                  <span class="span_err" id="inv1_tax_err"></span>
                </div>
              </div>
            </div> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Holding Nature</label> 
                  <select class="form-control" id="inv1_holding_nature" name="inv1_holding_nature">
                    <option value="">Select Holding Nature</option> 
                    <option value="single">Single</option> 
                    <option value="joint">Joint</option> 
                    <option value="either_or_survivor">Either OR Survivor</option>
                  </select> 
                  <span class="span_err" id="inv1_holding_nature_err"></span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Date of birth / Incorporation</label>
                  <input type="text" class="form-control dob" placeholder="Date of birth / Incorporation" id="inv1_dob" name="inv1_dob"> 
                  <span class="span_err" id="inv1_dob_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Gender</label> 
                  <select class="form-control" id="inv1_gender" name="inv1_gender">
                    <option value="">Select Gender</option> 
                    <option value="Male">Male</option> 
                    <option value="Female">Female</option> 
                  </select> 
                  <span class="span_err" id="inv1_gender_err"></span>
                </div>
              </div> 
            </div> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Dividend payout mode</label> 
                  <select class="form-control" id="inv1_dividend_payout" name="inv1_dividend_payout">
                    <option value="">Select Dividend payout mode</option> 
                    <option value="cheque">Cheque</option> 
                    <option value="direct_credit">Direct Credit</option> 
                    <option value="ecs">ECS</option> 
                    <option value="neft">NEFT</option> 
                    <option value="rtgs">RTGS</option>
                  </select> 
                  <span class="span_err" id="inv1_dividend_payout_err"></span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Occupation</label>
                  <input type="text" class="form-control" placeholder="Occupation" id="inv1_occupation" name="inv1_occupation"> 
                  <span class="span_err" id="inv1_occupation_err"></span>
                </div>
              </div> 
            </div>
          </div>
        </div> 
        <div class="panel panel-default">
          <div class="panel-heading"><b>Investor 2</b></div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>PAN Number</label>
                  <input type="text" class="form-control" placeholder="PAN Number" id="inv2_pan" name="inv2_pan"> 
                  <span class="span_err" id="inv2_pan_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Name as per PAN</label>
                  <input type="text" class="form-control" placeholder="Name as per PAN" id="inv2_name" name="inv2_name"> 
                  <span class="span_err" id="inv2_name_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Tax Status</label> 
                  <select class="form-control" id="inv2_tax" name="inv2_tax">
                    <option value="">Select Tax Status</option> 
                    <option value="individual">Individual</option> 
                    <option value="huf">HUF</option> 
                    <option value="partnership">Partnership</option> 
                    <option value="llp">LLP</option> 
                    <option value="company">Company</option> 
                    <option value="trust">Trust</option>
                  </select> 
                  <span class="span_err" id="inv2_tax_err"></span>
                </div>
              </div>
            </div> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Holding Nature</label> 
                  <select class="form-control" id="inv2_holding_nature" name="inv2_holding_nature">
                    <option value="">Select Holding Nature</option> 
                    <option value="single">Single</option> 
                    <option value="joint">Joint</option> 
                    <option value="either_or_survivor">Either OR Survivor</option>
                  </select> 
                  <span class="span_err" id="inv2_holding_nature_err"></span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Date of birth / Incorporation</label>
                  <input type="text" class="form-control dob" placeholder="Date of birth / Incorporation" id="inv2_dob" name="inv2_dob"> 
                  <span class="span_err" id="inv2_dob_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Gender</label> 
                  <select class="form-control" id="inv2_gender" name="inv2_gender">
                    <option value="">Select Gender</option> 
                    <option value="Male">Male</option> 
                    <option value="Female">Female</option> 
                  </select> 
                  <span class="span_err" id="inv2_gender_err"></span>
                </div>
              </div> 
            </div> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Dividend payout mode</label> 
                  <select class="form-control" id="inv2_dividend_payout" name="inv2_dividend_payout">
                    <option value="">Select Dividend payout mode</option> 
                    <option value="cheque">Cheque</option> 
                    <option value="direct_credit">Direct Credit</option> 
                    <option value="ecs">ECS</option> 
                    <option value="neft">NEFT</option> 
                    <option value="rtgs">RTGS</option>
                  </select> 
                  <span class="span_err" id="inv2_dividend_payout_err"></span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Occupation</label>
                  <input type="text" class="form-control" placeholder="Occupation" id="inv2_occupation" name="inv2_occupation"> 
                  <span class="span_err" id="inv2_occupation_err"></span>
                </div>
              </div> 
            </div>
          </div>
        </div> 
        <div class="panel panel-default">
          <div class="panel-heading"><b>Nominee Detail</b></div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Nominee Name</label>
                  <input type="text" class="form-control" placeholder="Nominee Name" id="nominee_name" name="nominee_name"> 
                  <span class="span_err" id="nominee_name_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Nominee Relation</label>
                  <input type="text" class="form-control" placeholder="Nominee Relation" id="nominee_relation" name="nominee_relation"> 
                  <span class="span_err" id="nominee_relation_err"></span>
                </div>
              </div>  
              <div class="col-md-4">
                <div class="form-group">
                  <label>Address 1</label>
                  <input type="text" class="form-control" placeholder="Address 1" id="nominee_address1" name="nominee_address1"> 
                  <span class="span_err" id="nominee_address1_err"></span>
                </div>
              </div> 
            </div> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Address 2</label>
                  <input type="text" class="form-control" placeholder="Address 2" id="nominee_address2" name="nominee_address2">
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Address 3</label>
                  <input type="text" class="form-control" placeholder="Address 3" id="nominee_address3" name="nominee_address3">
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Pincode</label>
                  <input type="text" class="form-control" placeholder="Pincode" id="nominee_pincode" name="nominee_pincode"> 
                  <span class="span_err" id="nominee_pincode_err"></span>
                </div>
              </div>  
            </div> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Country</label>
                  <input type="text" class="form-control" placeholder="Country" id="nominee_country" name="nominee_country" value="India" readonly="">
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>State</label>
                  <input type="text" class="form-control" placeholder="State" id="nominee_state" name="nominee_state"> 
                  <span class="span_err" id="nominee_state_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>City</label>
                  <input type="text" class="form-control" placeholder="City" id="nominee_city" name="nominee_city"> 
                  <span class="span_err" id="nominee_city_err"></span>
                </div>
              </div>  
            </div>
          </div>
        </div> 
        <div class="panel panel-default">
          <div class="panel-heading"><b>Address Detail</b></div>
          <div class="panel-body"> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Address 1</label>
                  <input type="text" class="form-control" placeholder="Address 1" id="address1" name="address1"> 
                  <span class="span_err" id="address1_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Address 2</label>
                  <input type="text" class="form-control" placeholder="Address 2" id="address2" name="address2">
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Address 3</label>
                  <input type="text" class="form-control" placeholder="Address 3" id="address3" name="address3">
                </div>
              </div>  
            </div> 
            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <label>Pincode</label>
                  <input type="text" class="form-control" placeholder="Pincode" id="pincode" name="pincode"> 
                  <span class="span_err" id="pincode_err"></span>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Country</label>
                  <input type="text" class="form-control" placeholder="Country" id="country" name="country" value="India" readonly=""> 
                  <span class="span_err" id="country_err"></span>
                </div>
              </div> 
              <div class="col-md-3">
                <div class="form-group">
                  <label>State</label>
                  <input type="text" class="form-control" placeholder="State" id="state" name="state"> 
                  <span class="span_err" id="state_err"></span>
                </div>
              </div> 
              <div class="col-md-3">
                <div class="form-group">
                  <label>City</label>
                  <input type="text" class="form-control" placeholder="City" id="city" name="city"> 
                  <span class="span_err" id="city_err"></span>
                </div>
              </div>  
            </div> 
            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <label>Residence phone</label>
                  <input type="text" class="form-control" placeholder="Residence phone" id="residence_phone" name="residence_phone"> 
                  <span class="span_err" id="residence_phone_err"></span>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Office phone</label>
                  <input type="text" class="form-control" placeholder="Office phone" id="office_phone" name="office_phone"> 
                  <span class="span_err" id="office_phone_err"></span>
                </div>
              </div> 
              <div class="col-md-3">
                <div class="form-group">
                  <label>Email</label>
                  <input type="text" class="form-control" placeholder="Email" id="email" name="email"> 
                  <span class="span_err" id="email_err"></span>
                </div>
              </div> 
              <div class="col-md-3">
                <div class="form-group">
                  <label>Mobile</label>
                  <input type="text" class="form-control" placeholder="Mobile" id="mobile" name="mobile"> 
                  <span class="span_err" id="mobile_err"></span>
                </div>
              </div>  
            </div>
          </div>
        </div> 
        <div class="panel panel-default">
          <div class="panel-heading"><b>Account Detail</b></div>
          <div class="panel-body bank-panel-body" id="dv_1">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Account Type</label> 
                  <select class="form-control" id="acc1_type" name="acc1_type">
                    <option value="">Select Account Type</option> 
                    <option value="savings">Savings</option> 
                    <option value="current">Current</option>
                  </select> 
                  <span class="span_err" id="acc1_type_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Account No.</label>
                  <input type="text" class="form-control" placeholder="Account No." id="acc1_no" name="acc1_no"> 
                  <span class="span_err" id="acc1_no_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>NEFT / IFSC Code</label>
                  <input type="text" class="form-control" placeholder="NEFT / IFSC Code" id="ifsc1" name="ifsc1"> 
                  <span class="span_err" id="ifsc1_err"></span>
                </div>
              </div>  
            </div> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>MICR No.</label>
                  <input type="text" class="form-control" placeholder="MICR No." id="micr1" name="micr1"> 
                  <span class="span_err" id="micr1_err"></span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Bank Name</label>
                  <input type="text" class="form-control" placeholder="Bank Name" id="bank1" name="bank1"> 
                  <span class="span_err" id="bank1_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Branch Name</label>
                  <input type="text" class="form-control" placeholder="Branch Name" id="branch1" name="branch1"> 
                  <span class="span_err" id="branch1_err"></span>
                </div>
              </div>  
            </div> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group"> 
                  <div class="radio">
                    <label>
                      <input type="radio" name="defaultbank" id="defaultbank1" value="default1" checked> Default Bank
                    </label>
                  </div>
                </div>
              </div>   
            </div>
          </div> 
          <div class="panel-body bank-panel-body" id="dv_2">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Account Type</label> 
                  <select class="form-control" id="acc2_type" name="acc2_type">
                    <option value="">Select Account Type</option> 
                    <option value="savings">Savings</option> 
                    <option value="current">Current</option>
                  </select> 
                  <span class="span_err" id="acc2_type_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Account No.</label>
                  <input type="text" class="form-control" placeholder="Account No." id="acc2_no" name="acc2_no"> 
                  <span class="span_err" id="acc2_no_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>NEFT / IFSC Code</label>
                  <input type="text" class="form-control" placeholder="NEFT / IFSC Code" id="ifsc2" name="ifsc2"> 
                  <span class="span_err" id="ifsc2_err"></span>
                </div>
              </div>  
            </div> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>MICR No.</label>
                  <input type="text" class="form-control" placeholder="MICR No." id="micr2" name="micr2"> 
                  <span class="span_err" id="micr2_err"></span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Bank Name</label>
                  <input type="text" class="form-control" placeholder="Bank Name" id="bank2" name="bank2"> 
                  <span class="span_err" id="bank2_err"></span>
                </div>
              </div> 
              <div class="col-md-4">
                <div class="form-group">
                  <label>Branch Name</label>
                  <input type="text" class="form-control" placeholder="Branch Name" id="branch2" name="branch2"> 
                  <span class="span_err" id="branch2_err"></span>
                </div>
              </div>  
            </div> 
            <div class="row">
              <div class="col-md-2">
                <div class="form-group"> 
                  <div class="radio">
                    <label>
                      <input type="radio" name="defaultbank" id="defaultbank2" value="default2"> Default Bank
                    </label>
                  </div>
                </div>
              </div>   
              <div class="col-md-2"> 
                <div class="form-group">  
                  <div class="checkbox"> 
                    <label> 
                      <input type="checkbox" name="removebank" id="removebank2"> Remove Bank 
                    </label>
                  </div> 
                </div> 
              </div> 
            </div>
          </div>
          <button type="button" class="btn btn-info add_bank_btn" style="margin-left: 12px; margin-bottom: 12px;">Add More Bank</button> 
          <button type="button" class="btn btn-danger remove_bank_btn" style="margin-left: 12px; margin-bottom: 12px; visibility: hidden;">Remove</button> 
          <input type="hidden" id="radio-previous">
        </div> 
        <div class="row">
          <div class="col-md-6">
            <div class="panel panel-default">
              <div class="panel-heading"><b>Investor 1 CKYC Detail</b></div>
              <div class="panel-body"> 
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>KYC Type</label> 
                      <select class="form-control" id="inv1_kyc_type" name="inv1_kyc_type">
                        <option value="">Select KYC Type</option> 
                        <option value="kra">KRA</option> 
                        <option value="ckyc">CKYC</option>
                      </select> 
                      <span class="span_err" id="inv1_kyc_type_err"></span>
                    </div>
                  </div> 
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>First holder CKYC number</label>
                      <input type="text" class="form-control" placeholder="First holder CKYC number" id="inv1_ckyc_no" name="inv1_ckyc_no"> 
                      <span class="span_err" id="inv1_ckyc_no_err"></span>
                    </div>
                  </div>  
                </div>
              </div>
            </div>
          </div> 
          <div class="col-md-6">
            <div class="panel panel-default">
              <div class="panel-heading"><b>Investor 2 CKYC Detail</b></div>
              <div class="panel-body"> 
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>KYC Type</label> 
                      <select class="form-control" id="inv2_kyc_type" name="inv2_kyc_type">
                        <option value="">Select KYC Type</option> 
                        <option value="kra">KRA</option> 
                        <option value="ckyc">CKYC</option>
                      </select> 
                      <span class="span_err" id="inv2_kyc_type_err"></span>
                    </div>
                  </div> 
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>First holder CKYC number</label>
                      <input type="text" class="form-control" placeholder="First holder CKYC number" id="inv2_ckyc_no" name="inv2_ckyc_no"> 
                      <span class="span_err" id="inv2_ckyc_no_err"></span>
                    </div>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
    <br>
<?php $this->load->view('scripts'); ?>
    <script type="text/javascript" src="<?= base_url(); ?>assets/sweetalert/sweetalert.min.js"></script>
    <script type="text/javascript"> 

      $("#inv1_pan, #inv2_pan, #mobile").attr("maxlength","10"); 
      $("#nominee_pincode, #pincode").attr("maxlength","6");  
      $("#dv_2").hide();  
      $('#dv_2').find('input, textarea, button, select').prop('disabled',true);

      $("#inv1_pan, #inv2_pan").on("keyup", function(){
        this.value = this.value.toUpperCase();
      }); 

      $("#ifsc1, #ifsc2").on("keyup", function(){
        this.value = this.value.toUpperCase();
      }); 

      $("#nominee_pincode, #pincode, #acc1_no, #acc2_no, #residence_phone, #office_phone, #mobile").on("keypress", function (e) {
        var keyCode = e.which ? e.which : e.keyCode
        if (!(keyCode >= 48 && keyCode <= 57)) {
          return false;
        }
      });

      $(document).on('click', '.add_bank_btn', function(){
        swal({
          title: "Are you sure?",
          text: "Do you want to add more bank?",
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Yes",
          closeOnConfirm: true
        },
        function(){ 
          $('#dv_2').find('input, textarea, button, select').prop('disabled',false);
          $("#dv_2").show(); 
          $(".add_bank_btn").hide(); 
          $('.remove_bank_btn').css('visibility','visible');
        });
      }); 
      
      $(document).on('click', '.remove_bank_btn', function(){
        swal({
          title: "Are you sure?",
          text: "Do you want to remove?",
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Yes",
          closeOnConfirm: true
        },
        function(){
          try{   
            var sel = $('input[type=checkbox]:checked').map(function(_, el) {
              return $(el).attr('id');
            }).get();  
            if( sel == '' ){
              alert("Please select atleast one bank"); 
            }
            else{
              for(var i=0;i<sel.length;i++){
                var cur_str = sel[i];
                var last_char = cur_str.charAt(cur_str.length-1); 
                $('#dv_'+last_char).remove();
              } 
              var numItems = $('.bank-panel-body').length; 
              if( numItems == 1 ){
                $(".add_bank_btn").show();
                $('.remove_bank_btn').css('visibility','hidden');
              }
            } 
          }
          catch(e){
            alert(e.message);
          }
        });
      });     

      $(document).on("change", "input[name*='defaultbank']", function(){
        var last_radio_val = $('#radio-previous').val(); 
        if( last_radio_val == '' ){
        }
        else{
          last_radio_val = parseInt(last_radio_val);
          $('#removebank'+last_radio_val).prop('disabled',false);
        }
        var x = $(this).attr('id');
        var last_char = x.charAt(x.length-1);  
        last_char = parseInt(last_char); 
        if( last_char > 1 ){ 
          $('#removebank'+last_char).prop('checked',false);
          $('#removebank'+last_char).prop('disabled',true);
          $('#radio-previous').val(last_char);
        }
        else{
          $('#radio-previous').val();
        }
      }); 

      $("#inv-form").on("submit", function(e){ 
        e.preventDefault();
        var frm = $(this); 
        $.ajax({
          url: frm.attr('action'),
          type: 'post',
          data: frm.serialize(),
          success: function(res){ 

            /*
            if(response.status == 'success') {
                $("#contactForm").hide();
            }
            $("#message").html(response.message); 
            */  

            var response = JSON.parse(res);
            if (response['n'] == 0) {
              bootbox.alert(response['msg']);
            }
            else if (response['n'] == 1) {
              $(':input','#inv-form')
              .not('#nominee_country, #country, #defaultbank1')
              .val('')
              .prop('checked', false)
              .prop('selected', false);
              bootbox.alert({
                //title: "Success !!!",
                message: response['msg'],
                callback: function () {
                  location.href = baseurl+"ucc/get_data/"+response['data']; 
                  // location.reload();
                }
              });
            }
            else if (response['n'] == 2) {
              valid(response['field'], response['msg']);
            }
            else {
              bootbox.alert('An error was encountered');
            }   
          },
          error: function(res){
            console.log(res);
          }
        });
      });   

    </script>
<?php $this->load->view('footer'); ?>