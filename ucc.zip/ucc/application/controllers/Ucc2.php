<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ucc2 extends CI_Controller {

	private $response = array();

	public function __construct() 
	{        
    parent::__construct();
  } 

	public function index()
	{
		$this->load->view('ucc_add2'); 
	} 

	public function store()
	{
		// echo "<pre>";print_r($_POST);echo "</pre>";exit;
		/*
		$response = array();  

		if( trim($_POST['inv1_pan']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv1_pan';
			$response['msg'] = "Please Enter PAN Number";
		} 
		else if( trim($_POST['inv1_pan']) != '' && !preg_match("/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/", trim($_POST['inv1_pan'])) ){
			$response['n'] = 2;
			$response['field'] = 'inv1_pan';
			$response['msg'] = "Please Enter Valid PAN Number";
		} 
		else if( trim($_POST['inv1_name']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv1_name';
			$response['msg'] = "Please Enter Name";
		} 
		else if( trim($_POST['inv1_name']) != '' && !preg_match("/^[a-zA-Z' ]+$/", trim($_POST['inv1_name'])) ){
			$response['n'] = 2;
			$response['field'] = 'inv1_name';
			$response['msg'] = "Not a valid name!! Enter as per PAN";
		}
		else if( trim($_POST['inv1_tax']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv1_tax';
			$response['msg'] = "Please select Tax Status";
		} 
		else if( trim($_POST['inv1_holding_nature']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv1_holding_nature';
			$response['msg'] = "Please select Holding Nature";
		} 
		else if( trim($_POST['inv1_dob']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv1_dob';
			$response['msg'] = "Please Enter Date of Birth / Incorporation";
		} 
		else if( trim($_POST['inv1_dob']) != '' && !preg_match("/^([0-2][0-9]|(3)[0-1])(\-)(((0)[0-9])|((1)[0-2]))(\-)\d{4}$/", trim($_POST['inv1_dob'])) ){
			$response['n'] = 2;
			$response['field'] = 'inv1_dob';
			$response['msg'] = "Please Enter Valid Date";
		} 
		else if( trim($_POST['inv1_gender']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv1_gender';
			$response['msg'] = "Please Select Gender";
		} 
		else if( trim($_POST['inv1_dividend_payout']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv1_dividend_payout';
			$response['msg'] = "Please Select Dividend Payout Mode";
		} 
		else if( trim($_POST['inv1_occupation']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv1_occupation';
			$response['msg'] = "Please Enter Occupation";
		} 
		else if( trim($_POST['inv2_pan']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv2_pan';
			$response['msg'] = "Please Enter PAN Number";
		} 
		else if( trim($_POST['inv2_pan']) != '' && !preg_match("/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/", trim($_POST['inv2_pan'])) ){
			$response['n'] = 2;
			$response['field'] = 'inv2_pan';
			$response['msg'] = "Please Enter Valid PAN Number";
		}  
		else if( trim($_POST['inv2_pan']) != '' && preg_match("/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/", trim($_POST['inv2_pan'])) && trim($_POST['inv2_pan']) == trim($_POST['inv1_pan']) ){
			$response['n'] = 2;
			$response['field'] = 'inv2_pan';
			$response['msg'] = "It should be different from Investor 1";
		} 
		else if( trim($_POST['inv2_name']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv2_name';
			$response['msg'] = "Please Enter Name";
		} 
		else if( trim($_POST['inv2_name']) != '' && !preg_match("/^[a-zA-Z\' ]+$/", trim($_POST['inv2_name'])) ){
			$response['n'] = 2;
			$response['field'] = 'inv2_name';
			$response['msg'] = "Not a valid name!! Enter as per PAN";
		}
		else if( trim($_POST['inv2_tax']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv2_tax';
			$response['msg'] = "Please select Tax Status";
		} 
		else if( trim($_POST['inv2_holding_nature']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv2_holding_nature';
			$response['msg'] = "Please select Holding Nature";
		} 
		else if( trim($_POST['inv2_dob']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv2_dob';
			$response['msg'] = "Please Enter Date of Birth / Incorporation";
		} 
		else if( trim($_POST['inv2_dob']) != '' && !preg_match("/^([0-2][0-9]|(3)[0-1])(\-)(((0)[0-9])|((1)[0-2]))(\-)\d{4}$/", trim($_POST['inv2_dob'])) ){
			$response['n'] = 2;
			$response['field'] = 'inv2_dob';
			$response['msg'] = "Please Enter Valid Date";
		} 
		else if( trim($_POST['inv2_gender']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv2_gender';
			$response['msg'] = "Please Select Gender";
		} 
		else if( trim($_POST['inv2_dividend_payout']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv2_dividend_payout';
			$response['msg'] = "Please Select Dividend Payout Mode";
		} 
		else if( trim($_POST['inv2_occupation']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv2_occupation';
			$response['msg'] = "Please Enter Occupation";
		}
		else if( trim($_POST['nominee_name']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'nominee_name';
			$response['msg'] = "Please Enter Name";
		} 
		else if( trim($_POST['nominee_name']) != '' && !preg_match("/^[a-zA-Z' ]+$/", trim($_POST['nominee_name'])) ){
			$response['n'] = 2;
			$response['field'] = 'nominee_name';
			$response['msg'] = "Not a valid name";
		} 
		else if( trim($_POST['nominee_relation']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'nominee_relation';
			$response['msg'] = "Please Enter Nominee Relation";
		} 
		else if( trim($_POST['nominee_relation']) != '' && !preg_match("/^[a-zA-Z ]+$/", trim($_POST['nominee_relation'])) ){
			$response['n'] = 2;
			$response['field'] = 'nominee_relation';
			$response['msg'] = "Only Characters are allowed";
		} 
		else if( trim($_POST['nominee_address1']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'nominee_address1';
			$response['msg'] = "Please Enter Adderss";
		} 
		else if( trim($_POST['nominee_pincode']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'nominee_pincode';
			$response['msg'] = "Please Enter Nominee Pincode";
		} 
		else if( trim($_POST['nominee_pincode']) != '' && !preg_match("/^[0-9]{6}$/", trim($_POST['nominee_pincode'])) ){
			$response['n'] = 2;
			$response['field'] = 'nominee_pincode';
			$response['msg'] = "Please enter valid 6 digit Pincode";
		} 
		else if( trim($_POST['nominee_state']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'nominee_state';
			$response['msg'] = "Please Enter State";
		} 
		else if( trim($_POST['nominee_city']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'nominee_city';
			$response['msg'] = "Please Enter City";
		} 
		else if( trim($_POST['address1']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'address1';
			$response['msg'] = "Please Enter Adderss";
		}
		else if( trim($_POST['pincode']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'pincode';
			$response['msg'] = "Please Enter Pincode";
		} 
		else if( trim($_POST['pincode']) != '' && !preg_match("/^[0-9]{6}$/", trim($_POST['pincode'])) ){
			$response['n'] = 2;
			$response['field'] = 'pincode';
			$response['msg'] = "Please enter valid 6 digit Pincode";
		} 
		else if( trim($_POST['state']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'state';
			$response['msg'] = "Please Enter State";
		} 
		else if( trim($_POST['city']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'city';
			$response['msg'] = "Please Enter City";
		} 
		else if( trim($_POST['residence_phone']) != '' && !preg_match("/^\d*$/", trim($_POST['residence_phone'])) ){
			$response['n'] = 2;
			$response['field'] = 'residence_phone';
			$response['msg'] = "Please enter valid Residence Phone";
		} 
		else if( trim($_POST['office_phone']) != '' && !preg_match("/^\d*$/", trim($_POST['office_phone'])) ){
			$response['n'] = 2;
			$response['field'] = 'office_phone';
			$response['msg'] = "Please enter valid Office Phone";
		} 
		else if( trim($_POST['email']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'email';
			$response['msg'] = "Please Enter Email";
		} 
		else if( trim($_POST['email']) != '' && !preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/", trim($_POST['email'])) ){
			$response['n'] = 2;
			$response['field'] = 'email';
			$response['msg'] = "Please enter valid Email";
		} 
		else if( trim($_POST['mobile']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'mobile';
			$response['msg'] = "Please Enter Mobile";
		} 
		else if( trim($_POST['mobile']) != '' && !preg_match("/^\d{10}$/", trim($_POST['mobile'])) ){
			$response['n'] = 2;
			$response['field'] = 'mobile';
			$response['msg'] = "Please enter valid 10 Digit Mobile";
		} 
		else if( trim($_POST['acc1_type']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'acc1_type';
			$response['msg'] = "Please Select Account Type";
		} 
		else if( trim($_POST['acc1_no']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'acc1_no';
			$response['msg'] = "Please Enter Account No.";
		} 
		else if( trim($_POST['acc1_no']) != '' && !preg_match("/^\d*$/", trim($_POST['acc1_no'])) ){
			$response['n'] = 2;
			$response['field'] = 'acc1_no';
			$response['msg'] = "Only numbers are allowed";
		} 
		else if( trim($_POST['ifsc1']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'ifsc1';
			$response['msg'] = "Please Enter IFSC Code";
		} 
		else if( trim($_POST['ifsc1']) != '' && !preg_match("/^[A-Z]{4}[0]{1}[0-9]{6}$/", trim($_POST['ifsc1'])) ){
			$response['n'] = 2;
			$response['field'] = 'ifsc1';
			$response['msg'] = "Please Enter Valid IFSC Code";
		} 
		else if( trim($_POST['micr1']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'micr1';
			$response['msg'] = "Please Enter MICR No.";
		} 
		else if( trim($_POST['micr1']) != '' && !preg_match("/^[0-9]{9}$/", trim($_POST['micr1'])) ){
			$response['n'] = 2;
			$response['field'] = 'micr1';
			$response['msg'] = "Please enter valid 9 Digit MICR No.";
		} 
		else if( trim($_POST['bank1']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'bank1';
			$response['msg'] = "Please Enter Bank Name";
		} 
		else if( trim($_POST['branch1']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'branch1';
			$response['msg'] = "Please Enter Branch Name";
		} 
		else if( isset($_POST['acc2_type']) && trim($_POST['acc2_type']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'acc2_type';
			$response['msg'] = "Please Select Account Type";
		} 
		else if( isset($_POST['acc2_no']) && trim($_POST['acc2_no']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'acc2_no';
			$response['msg'] = "Please Enter Account No.";
		} 
		else if( isset($_POST['acc2_no']) && trim($_POST['acc2_no']) != '' && !preg_match("/^\d*$/", trim($_POST['acc2_no'])) ){
			$response['n'] = 2;
			$response['field'] = 'acc2_no';
			$response['msg'] = "Only numbers are allowed";
		}  
		else if( isset($_POST['acc2_no']) && trim($_POST['acc2_no']) != '' && trim($_POST['acc2_no']) == trim($_POST['acc1_no']) ){
			$response['n'] = 2;
			$response['field'] = 'acc2_no';
			$response['msg'] = "It should be different from previous one";
		} 
		else if( isset($_POST['ifsc2']) && trim($_POST['ifsc2']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'ifsc2';
			$response['msg'] = "Please Enter IFSC Code";
		} 
		else if( isset($_POST['ifsc2']) && trim($_POST['ifsc2']) != '' && !preg_match("/^[A-Z]{4}[0]{1}[0-9]{6}$/", trim($_POST['ifsc2'])) ){
			$response['n'] = 2;
			$response['field'] = 'ifsc2';
			$response['msg'] = "Please Enter Valid IFSC Code";
		} 
		else if( isset($_POST['ifsc2']) && trim($_POST['ifsc2']) != '' && trim($_POST['ifsc2']) == trim($_POST['ifsc1']) ){
			$response['n'] = 2;
			$response['field'] = 'ifsc2';
			$response['msg'] = "It should be different from previous one";
		} 
		else if( isset($_POST['micr2']) && trim($_POST['micr2']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'micr2';
			$response['msg'] = "Please Enter MICR No.";
		} 
		else if( isset($_POST['micr2']) && trim($_POST['micr2']) != '' && !preg_match("/^\d{9}$/", trim($_POST['micr2'])) ){
			$response['n'] = 2;
			$response['field'] = 'micr2';
			$response['msg'] = "Please enter valid 9 Digit MICR No.";
		}
		else if( isset($_POST['micr2']) && trim($_POST['micr2']) != '' && trim($_POST['micr2']) == trim($_POST['micr1'])){
			$response['n'] = 2;
			$response['field'] = 'micr2';
			$response['msg'] = "It should be different from previous one";
		} 
		else if( isset($_POST['bank2']) && trim($_POST['bank2']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'bank2';
			$response['msg'] = "Please Enter Bank Name";
		} 
		else if( isset($_POST['branch2']) && trim($_POST['branch2']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'branch2';
			$response['msg'] = "Please Enter Branch Name";
		} 
		else if( trim($_POST['inv1_kyc_type']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv1_kyc_type';
			$response['msg'] = "Please select KYC Type";
		} 
		else if( trim($_POST['inv1_ckyc_no']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv1_ckyc_no';
			$response['msg'] = "Please enter first holder CKYC No.";
		} 
		else if( trim($_POST['inv2_kyc_type']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv2_kyc_type';
			$response['msg'] = "Please select KYC Type";
		} 
		else if( trim($_POST['inv2_ckyc_no']) == '' ){
			$response['n'] = 2;
			$response['field'] = 'inv2_ckyc_no';
			$response['msg'] = "Please enter first holder CKYC No.";
		}
		else{ 
			$data = array(
				'client_code'               => rand(1000000,9999999),
				'member_code'               => rand(1000000,9999999), 
				'inv1_pan_no'               => trim($_POST['inv1_pan']),
				'inv1_name'                 => trim($_POST['inv1_name']),
				'inv1_tax_status'           => trim($_POST['inv1_tax']),
				'inv1_holding_nature'       => trim($_POST['inv1_holding_nature']),
				'inv1_dob'                  => trim($_POST['inv1_dob']), 
				'inv1_gender'               => trim($_POST['inv1_gender']),
				'inv1_dividend_payout_mode' => trim($_POST['inv1_dividend_payout']),
				'inv1_occupation'           => trim($_POST['inv1_occupation']),
				'inv2_pan_no'               => trim($_POST['inv2_pan']),
				'inv2_name'                 => trim($_POST['inv2_name']),
				'inv2_tax_status'           => trim($_POST['inv2_tax']),
				'inv2_holding_nature'       => trim($_POST['inv2_holding_nature']),
				'inv2_dob'                  => trim($_POST['inv2_dob']), 
				'inv2_gender'               => trim($_POST['inv2_gender']),
				'inv2_dividend_payout_mode' => trim($_POST['inv2_dividend_payout']),
				'inv2_occupation'           => trim($_POST['inv2_occupation']), 
				'nominee_name'              => trim($_POST['nominee_name']),
				'nominee_relation'          => trim($_POST['nominee_relation']),
				'nominee_address'           => trim($_POST['nominee_address1'])." ".trim($_POST['nominee_address2'])." ".trim($_POST['nominee_address3']),
				'nominee_pincode'           => trim($_POST['nominee_pincode']),
				'nominee_country'           => trim($_POST['nominee_country']),
				'nominee_state'             => trim($_POST['nominee_state']),
				'nominee_city'              => trim($_POST['nominee_city']),
				'address'                   => trim($_POST['address1'])." ".trim($_POST['address2'])." ".trim($_POST['address3']),
				'pincode'                   => trim($_POST['pincode']),
				'country'                   => trim($_POST['country']),
				'state'                     => trim($_POST['state']),
				'city'                      => trim($_POST['city']),
				'res_phone'                 => trim($_POST['residence_phone']),
				'off_phone'                 => trim($_POST['office_phone']),
				'email'                     => trim($_POST['email']),
				'mobile'                    => trim($_POST['mobile']),
				'acc1_type'                 => trim($_POST['acc1_type']),
				'acc1_no'                   => trim($_POST['acc1_no']),
				'acc1_ifsc'                 => trim($_POST['ifsc1']),
				'acc1_micr'                 => trim($_POST['micr1']),
				'acc1_bank_name'            => trim($_POST['bank1']),
				'acc1_branch_name'          => trim($_POST['branch1']), 
				'inv1_kyc_type'             => trim($_POST['inv1_kyc_type']),
				'inv1_ckyc_number'          => trim($_POST['inv1_ckyc_no']),
				'inv2_kyc_type'             => trim($_POST['inv2_kyc_type']),
				'created_date'              => date("Y-m-d H:i:s")
			); 

			if( isset($_POST['acc2_type']) ){
				$data += array(
					'acc2_type'        => trim($_POST['acc2_type']),
					'acc2_no'          => trim($_POST['acc2_no']),
					'acc2_ifsc'        => trim($_POST['ifsc2']),
					'acc2_micr'        => trim($_POST['micr2']),
					'acc2_bank_name'   => trim($_POST['bank2']),
					'acc2_branch_name' => trim($_POST['branch2'])
				);
			}			 

			$data += array('default_bank' => trim($_POST['defaultbank'])); 

			$id = $this->investors_model->save($data); 

			$response['n'] = 1;
			$response['msg'] = "Submitted Successfully";
			$response['data'] = $id;
		}

		echo json_encode($response);
		*/    

		// echo "<pre>";print_r($_POST);echo "</pre>";exit;

		$this->config->load('validation_rules'); 
		$this->form_validation->set_rules($this->config->item('user')); 
		$essential_fields = array(
																'fullname',
																'gender',
																'pro_langs',
																'marital_status',
																'address',
																'pic'
															); 
		$fields_having_array = array('pro_langs'); 
		$fields_having_file_upload = array('pic');
		if ($this->form_validation->run()) 
		{
			$data = $this->arrange_form_data($essential_fields, $fields_having_array, $fields_having_file_upload);
			$this->users_model->save($this->security->xss_clean($data)); 
			$this->response['error'] = false;
			$this->response['msg'] = "Submitted Successfully";
		}
		else 
		{
			$this->response['error'] = true;
			$this->response['fields'] = $this->show_fields_errors($essential_fields, $fields_having_array);
		}
		$this->output
						    ->set_content_type('application/json')
						    ->set_output(json_encode($this->response));
	}  

	private function show_fields_errors($essential_fields, $fields_having_array)
	{
		foreach($essential_fields as $field_key => $field_name)
		{
			if(in_array($field_name, $fields_having_array)) 
			{
				$data[$field_name] = form_error($field_name.'[]');
			}
			else
			{
				$data[$field_name] = form_error($field_name);
			}
		} 
		return $data;
	} 

	private function arrange_form_data($essential_fields, $fields_having_array, $fields_having_file_upload)
	{
		foreach($essential_fields as $field_key => $field_name) 
		{
			if(in_array($field_name, $fields_having_array)) 
			{
				$data['user_'.$field_name] = implode(',', $this->input->post($field_name.'[]'));
			}
			else if(in_array($field_name, $fields_having_file_upload)) 
			{
				$data['user_'.$field_name] = $_FILES[$field_name]['name'];
			}
			else
			{
				$data['user_'.$field_name] = $this->input->post($field_name);
			}
		} 
		$data['user_created_at'] = date("Y-m-d H:i:s"); 
		return $data;
	}

	public function check_valid_name($str) 
	{
		if($str == '') 
		{
			$this->form_validation->set_message('check_valid_name', 'The %s field is required');
			return FALSE;
		}
		else if(!preg_match("/^[a-zA-Z' ]+$/", $str)) 
		{
			$this->form_validation->set_message('check_valid_name', 'Please Enter Valid Name');
			return FALSE;
		}
		else 
		{ 
			return TRUE;
		} 
	} 

	public function check_programming_language() 
	{ 
		if( $this->input->post('pro_langs[]') != '' )
		{  
			$default_count = 2;
			if( count( $this->input->post('pro_langs[]') ) >= $default_count )
			{
				return TRUE;
			}
			else
			{
				$this->form_validation->set_message('check_programming_language', 'Select minimum '.$default_count.' %s');
				return FALSE;
			} 
		}
		else
		{
			$this->form_validation->set_message('check_programming_language', 'The %s field is required');
			return FALSE;
		} 
	} 

	public function check_picture() 
	{ 
		// to rename file
		$file_ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION); 
    $_FILES['pic']['name'] = time().'.'.$file_ext;
		
		// file configuration
		$config['upload_path']          = './uploads/';
    $config['allowed_types']        = 'jpg|jpeg|pdf';
    $config['max_size']             = 1024;
    $config['max_width']            = 1024;
    $config['max_height']           = 768;
    $this->load->library('upload', $config);
    if (!$this->upload->do_upload('pic')) 
    {      
      $this->form_validation->set_message('check_picture', strip_tags($this->upload->display_errors()));
			return FALSE;
    }
    else 
    {
      return TRUE;
    } 

	} 

	/*
	public function get_data($id){
		// $data['inv_data'] = $this->investors_model->get_data($id);

		$inv_data = $this->investors_model->get_data($id);
		$this->load->library('Pdf'); 
		// $this->load->view('create_pdf2', $data); 

		// echo "<pre>";print_r($inv_data);echo "</pre>";exit;
		$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
		// $pdf->SetTitle('My Title');
		// $pdf->SetHeaderMargin(30);
		// $pdf->SetTopMargin(20);
		// $pdf->setFooterMargin(20);

		$pdf->setPrintHeader(false);
		$pdf->setPrintFooter(false);

		// $pdf->SetAutoPageBreak(true, 0);
		// $pdf->SetAuthor('Author');
		// $pdf->SetDisplayMode('real', 'default');

		$pdf->AddPage();

		// $pdf->Write(5, 'Some sample text');  

		// $img_path = base_url().'assets/smpl.png'; 
		$img_path = '../../assets/smpl.png';  

		$html = '';  

		$html .= '
			<b>&nbsp;&nbsp;&nbsp;&nbsp;Client code: </b>'.$inv_data[0]['client_code'].'
			<br>
			<b>Member code: </b>'.$inv_data[0]['member_code'].'
			<br><br>
		'; 

		$html .= '
			<table border="1" cellpadding="2">
				<tr> 
					<td colspan="2"><b>Investor 1 Detail</b></td>
				</tr>
				<tr>
					<td width="31%"><b>PAN Number </b></td>
					<td width="69%">'.$inv_data[0]['inv1_pan_no'].'</td> 
				</tr> 
				<tr>
					<td width="31%"><b>Name as per PAN </b></td>
					<td width="69%">'.$inv_data[0]['inv1_name'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Tax Status </b></td>
					<td width="69%">'.$inv_data[0]['inv1_tax_status'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Holding Nature </b></td>
					<td width="69%">'.$inv_data[0]['inv1_holding_nature'].'</td> 
				</tr> 
				<tr>
					<td width="31%"><b>Date of birth / Incorporation </b></td>
					<td width="69%">'.$inv_data[0]['inv1_dob'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Gender </b></td>
					<td width="69%">'.$inv_data[0]['inv1_gender'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Dividend payout mode </b></td>
					<td width="69%">'.$inv_data[0]['inv1_dividend_payout_mode'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Occupation </b></td>
					<td width="69%">'.$inv_data[0]['inv1_occupation'].'</td> 
				</tr> 
			</table>
			<br><br>
		'; 

		$html .= '
			<table border="1" cellpadding="2">
				<tr> 
					<td colspan="2"><b>Investor 2 Detail</b></td>
				</tr>
				<tr>
					<td width="31%"><b>PAN Number </b></td>
					<td width="69%">'.$inv_data[0]['inv2_pan_no'].'</td> 
				</tr> 
				<tr>
					<td width="31%"><b>Name as per PAN </b></td>
					<td width="69%">'.$inv_data[0]['inv2_name'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Tax Status </b></td>
					<td width="69%">'.$inv_data[0]['inv2_tax_status'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Holding Nature </b></td>
					<td width="69%">'.$inv_data[0]['inv2_holding_nature'].'</td> 
				</tr> 
				<tr>
					<td width="31%"><b>Date of birth / Incorporation </b></td>
					<td width="69%">'.$inv_data[0]['inv2_dob'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Gender </b></td>
					<td width="69%">'.$inv_data[0]['inv2_gender'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Dividend payout mode </b></td>
					<td width="69%">'.$inv_data[0]['inv2_dividend_payout_mode'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Occupation </b></td>
					<td width="69%">'.$inv_data[0]['inv2_occupation'].'</td> 
				</tr> 
			</table> 
			<br><br>
		'; 

		$html .= '
			<table border="1" cellpadding="2">
				<tr> 
					<td colspan="2"><b>Nominee Detail</b></td>
				</tr> 
				<tr>
					<td width="31%"><b>Name </b></td>
					<td width="69%">'.$inv_data[0]['nominee_name'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Relation </b></td>
					<td width="69%">'.$inv_data[0]['nominee_relation'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Address </b></td>
					<td width="69%">'.$inv_data[0]['nominee_address'].'</td> 
				</tr> 
				<tr>
					<td width="31%"><b>Pincode </b></td>
					<td width="69%">'.$inv_data[0]['nominee_pincode'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Country </b></td>
					<td width="69%">'.$inv_data[0]['nominee_country'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>State </b></td>
					<td width="69%">'.$inv_data[0]['nominee_state'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>City </b></td>
					<td width="69%">'.$inv_data[0]['nominee_city'].'</td> 
				</tr> 
			</table>
			<br><br>
		'; 

		$html .= '
			<table border="1" cellpadding="2" style="page-break-after: always;">
				<tr> 
					<td colspan="2"><b>Address Detail</b></td>
				</tr> 
				<tr>
					<td width="31%"><b>Address </b></td>
					<td width="69%">'.$inv_data[0]['address'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Pincode </b></td>
					<td width="69%">'.$inv_data[0]['pincode'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Country </b></td>
					<td width="69%">'.$inv_data[0]['country'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>State </b></td>
					<td width="69%">'.$inv_data[0]['state'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>City </b></td>
					<td width="69%">'.$inv_data[0]['city'].'</td> 
				</tr> 
			</table>
			<br><br>
		'; 

		$html .= '
			<table border="1" cellpadding="2">
				<tr> 
					<td colspan="2"><b>Account '.$this->check_for_multiple_bank($inv_data[0]['default_bank']).' Detail</b></td>
				</tr> 
				<tr>
					<td width="31%"><b>Account Type </b></td>
					<td width="69%">'.$inv_data[0]['acc1_type'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Account Number </b></td>
					<td width="69%">'.$inv_data[0]['acc1_no'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>IFSC Code </b></td>
					<td width="69%">'.$inv_data[0]['acc1_ifsc'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>MICR Number </b></td>
					<td width="69%">'.$inv_data[0]['acc1_micr'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>Bank Name </b></td>
					<td width="69%">'.$inv_data[0]['acc1_bank_name'].'</td> 
				</tr> 
				<tr>
					<td width="31%"><b>Branch Name </b></td>
					<td width="69%">'.$inv_data[0]['acc1_branch_name'].'</td> 
				</tr> 
				<tr>
					<td width="31%"><b>Default Bank </b></td>
					<td width="69%">'.$this->check_default_bank($inv_data[0]['default_bank'], "default1").'</td> 
				</tr> 
			</table> 
			<br><br>
		';  

		if($inv_data[0]['default_bank'] == "default2"){

			$html .= '
				<table border="1" cellpadding="2">
					<tr> 
						<td colspan="2"><b>Account 2 Detail</b></td>
					</tr> 
					<tr>
						<td width="31%"><b>Account Type </b></td>
						<td width="69%">'.$inv_data[0]['acc2_type'].'</td> 
					</tr>
					<tr>
						<td width="31%"><b>Account Number </b></td>
						<td width="69%">'.$inv_data[0]['acc2_no'].'</td> 
					</tr>
					<tr>
						<td width="31%"><b>IFSC Code </b></td>
						<td width="69%">'.$inv_data[0]['acc2_ifsc'].'</td> 
					</tr>
					<tr>
						<td width="31%"><b>MICR Number </b></td>
						<td width="69%">'.$inv_data[0]['acc2_micr'].'</td> 
					</tr>
					<tr>
						<td width="31%"><b>Bank Name </b></td>
						<td width="69%">'.$inv_data[0]['acc2_bank_name'].'</td> 
					</tr> 
					<tr>
						<td width="31%"><b>Branch Name </b></td>
						<td width="69%">'.$inv_data[0]['acc2_branch_name'].'</td> 
					</tr> 
					<tr>
						<td width="31%"><b>Default Bank </b></td>
						<td width="69%">'.$this->check_default_bank($inv_data[0]['default_bank'], "default2").'</td> 
					</tr> 
				</table>
				<br><br>
			';

		}

		$html .= '
			<table border="1" cellpadding="2">
				<tr> 
					<td colspan="2"><b>Investor 1 CKYC Detail</b></td>
				</tr> 
				<tr>
					<td width="31%"><b>KYC Type </b></td>
					<td width="69%">'.$inv_data[0]['inv1_kyc_type'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>First holder CKYC number </b></td>
					<td width="69%">'.$inv_data[0]['inv1_ckyc_number'].'</td> 
				</tr> 
			</table> 
			<br><br>
		';  

		$html .= '
			<table border="1" cellpadding="2">
				<tr> 
					<td colspan="2"><b>Investor 2 CKYC Detail</b></td>
				</tr> 
				<tr>
					<td width="31%"><b>KYC Type </b></td>
					<td width="69%">'.$inv_data[0]['inv2_kyc_type'].'</td> 
				</tr>
				<tr>
					<td width="31%"><b>First holder CKYC number </b></td>
					<td width="69%">'.$inv_data[0]['inv1_ckyc_number'].'</td> 
				</tr> 
			</table> 
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		'; 

		$html .= '
			<table style="cellpadding: 2px;">
				<tr>
					<td width="5%"></td>
					<td width="40%"><hr></td> 
					<td width="5%"></td>
					<td width="5%"></td> 
					<td width="40%"><hr></td>
					<td width="5%"></td>
				</tr>
				<tr> 
					<td width="5%"></td>
					<td width="40%" align="center">Signature</td> 
					<td width="5%"></td>
					<td width="5%"></td> 
					<td width="40%" align="center">Signature</td>
					<td width="5%"></td>
				</tr> 
			</table>
		'; 

		$pdf->writeHTML($html, true, false, true, false, '');

		$pdf->Output(time().'.pdf', 'D');   
	}
	*/ 

	/*
	private function check_default_bank($stored_data, $cur_data){
		return ( $stored_data == $cur_data )?"yes":"no";
	} 
	*/

	/*
	private function check_for_multiple_bank($stored_data){
		return ( $stored_data == "default2" )?"1":"";
	}
	*/

}
