<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users_Model extends CI_Model{
	
	public function save($data) 
	{
		$this->db->insert("users", $data);
  	return $this->db->insert_id();
	}  

}