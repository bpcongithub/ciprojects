<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Investors_Model extends CI_Model{
	
	public function save($data) {
		$this->db->insert("investors", $data);
  	return $this->db->insert_id();
	}  

	public function get_data($id) {
		$this->db->where('inv_id', $id);
   	return $this->db->get("investors")->result_array();
	} 

	public function save_sign($data, $id) {
  	$this->db->where("inv_id", $id);
		$this->db->update("investors", $data);
	}
}